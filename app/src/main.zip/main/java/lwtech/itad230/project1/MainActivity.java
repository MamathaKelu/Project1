package lwtech.itad230.project1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    ImageButton floatButton;
    public static final int EDIT_REQUEST = 1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        floatButton  = (ImageButton) findViewById(R.id.imageButton);

        floatButton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                Toast.makeText(getApplicationContext(),"Button is clicked", Toast.LENGTH_SHORT).show();
                getButtonName("");
            }
        }
        );


    }

    protected void getButtonName(String msg)
    {
        Intent intent = new Intent(this, ButtonCreate.class);
        //intent.putExtra(ButtonCreate.EXTRA_MESSAGE, " hi ");
        startActivityForResult(intent, EDIT_REQUEST);
    }

    /**
     * onActivityResult called when another activity sends result
     * @param requestCode - request code tom be respond to
     * @param resultCode - result code successul or cancel
     * @param data result
     */
    @Override
    protected void onActivityResult(int requestCode,int resultCode, Intent data) {
        // Check which request we're responding to
        if (requestCode == EDIT_REQUEST) {
            // Make sure the request was successful
            Log.d("DEBUG","....CODE....");
            if (resultCode == RESULT_OK) {
                Log.d("DEBUG","....RESULT....");

                // The edit was successful, change the EditText widget's text
                String strResult = data.getStringExtra(ButtonCreate.EDIT_RESULT);
                createButton(strResult);
            }
        }
    }

    private void createButton(String strResult) {
        Log.d("DEBUG","....CREATE BUTTON....");
        TableLayout table = (TableLayout)findViewById(R.id.tableForButtons);
        //for(int i=0;i<3;i++);
        {
            TableRow tableRow = new TableRow(this);
            tableRow.setLayoutParams(new TableLayout.LayoutParams(
                    TableLayout.LayoutParams.MATCH_PARENT,
                    TableLayout.LayoutParams.MATCH_PARENT,
                    1.0f
            ));
            table.addView(tableRow);
            //for (int j = 0; j < 3; j++) ;
            {
                Button button = new Button(this);
                tableRow.setLayoutParams(new TableRow.LayoutParams(
                        TableRow.LayoutParams.MATCH_PARENT,
                        TableRow.LayoutParams.MATCH_PARENT,
                        1.0f
                ));
                tableRow.addView(button);

                button.setText(strResult);
                button.setOnClickListener(new View.OnClickListener() {
                  @Override
                  public void onClick(View v) {
                      gridButtonClicked();
                  }
              });
            }
        }
    }

    private void gridButtonClicked() {
        Toast.makeText(getApplicationContext(),"Created button clicked", Toast.LENGTH_SHORT).show();


    }


}
