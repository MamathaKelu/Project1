package lwtech.itad230.project1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class ButtonCreate extends AppCompatActivity {

    private EditText messageView;
    public static final String EDIT_RESULT = "EditResult";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_button_create);
       messageView = (EditText)findViewById(R.id.folderName);
    }
    /**
     * onClickOk handler for OK button
     * @param view
     */
    protected void onClickOk(View view) {
        String message = messageView.getText().toString();
        Intent intent = new Intent();
        /*Send the result in extras*/
        intent.putExtra(EDIT_RESULT, message);
        setResult(RESULT_OK, intent);
        finish();
    }

    /**
     *onClickCancel handler for cancel button
     * @param view
     */
    protected void onClickCancel(View view) {
        setResult(RESULT_CANCELED);
        finish();
    }
}
